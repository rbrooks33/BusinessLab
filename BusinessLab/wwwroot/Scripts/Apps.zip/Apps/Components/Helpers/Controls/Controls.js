﻿define([], function () {
    var Me = {
        Initialize: function (callback) {

            callback();
        },
        UniqueID: function () {

        },
        VariableDelimiter: function () { },
        EditorType: function () { }
    };
    return Me;
})