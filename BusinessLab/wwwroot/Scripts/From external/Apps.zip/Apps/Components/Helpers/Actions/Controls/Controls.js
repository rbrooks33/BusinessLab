﻿define([], function () {
    var Me = {
        UniqueID: function () {

        }
    };
    return Me;
});