﻿define([], function () {
    var Me = {
        Settings: [],
        Initialize: function (callback) {

            if (callback)
                callback();

        },
        RefreshUserSettings: function () {

            let post = Me.Parent.Data.Posts.Main;

            let request = {
                Params: [
                    { Name: "RequestCommand", Value: "GetAllUserSettings" }
                ]
            }

            post.Refresh(request, [], function () {
                if (post.Success) {

                    Me.Settings = post.Data;

                }
                else {
                    Apps.Notify('danger', 'Failed getting user settings.');

                }
            });

        }

    };
    return Me;
});