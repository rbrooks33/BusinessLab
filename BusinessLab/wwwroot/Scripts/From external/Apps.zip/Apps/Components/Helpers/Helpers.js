﻿define([], function () {
    var Me = {
        Initialize: function (callback) {

            let url = Apps.ActiveDeployment.WebRoot + '/api/Helpers';

            //Main (universal api)
            Apps.Data.RegisterMyPOST(Me, 'Main', url, [], true);
            Apps.Data.RegisterMyPOST(Me, 'MainAsync', url, [], false);
            Apps.Data.RegisterMyGET(Me, 'Main', url, [], true);

            //TODO: Migrate to these:
            Apps.Data.RegisterMyPOST(Me, 'HelpersPost', url, [], true);
            Apps.Data.RegisterMyPOST(Me, 'HelpersPostAsync', url, [], false);
            Apps.Data.RegisterMyGET(Me, 'HelpersGet', url, [], true);

            callback();
        },

        OpenResponse: function (resultEscapedString) {
            let resultString = unescape(resultEscapedString);
            Apps.Components.Helpers.Dialogs.Content('Helpers_Exception_Dialog', resultString);
            //Apps.Components.Helpers.Dialogs.Close('Helpers_Exception_Dialog');
            Apps.Components.Helpers.Dialogs.Open('Helpers_Exception_Dialog');

        },
        HandleError: function (result) {

            vNotify.error({ text: 'A problem ocurred on the server.', title: 'Server Error', sticky: false, showClose: true });
            let textDiv = $('body > div.vnotify-container.vn-top-right > div > div.vnotify-text');
            textDiv.append('<div class="btn btn-dark" style="margin-top:10px;" onclick="Apps.Components.Helpers.OpenResponse(\'' + escape(JSON.stringify(result)) + '\');">View Response</div>');

            Apps.Notify('danger', 'Problem getting report.');
            $('#Admin_Editor_EditSaveResult').text(JSON.stringify(result));

        }

    };
    return Me;
});