﻿define([], function () {
    var Me = {
        Initialize: function (callback) {

            callback();
        },
        UniqueID: function () {

        }
    };
    return Me;
})