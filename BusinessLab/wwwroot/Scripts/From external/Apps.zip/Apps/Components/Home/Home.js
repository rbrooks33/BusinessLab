﻿define([], function () {
    var Me = {
        Name: 'Home',
        Color: '#1961AE',
        Reports: null,
        Controls: null,
        Initialize: function (callback) {

            //Main: Used for internal methods
            Apps.Data.RegisterMyPOST(Me, 'Main', Apps.ActiveDeployment.WebRoot + '/api/main', [], true);
            Apps.Data.RegisterMyPOST(Me, 'MainAsync', Apps.ActiveDeployment.WebRoot + '/api/main', [], false);

            //Actions (universal actions)
            Apps.Data.RegisterMyPOST(Me, 'Helpers', Apps.ActiveDeployment.WebRoot + '/api/helpers', [], true);
            Apps.Data.RegisterMyPOST(Me, 'HelpersAsync', Apps.ActiveDeployment.WebRoot + '/api/helpers', [], false);

            //TODO: Migrate to this name convention
            //Apps.Data.RegisterMyPOST(Me, 'HomePost', Apps.ActiveDeployment.WebRoot + '/api/main', [], true);

            //Files
            //Apps.Data.RegisterMyUpload(Me, 'Files', base + '/FilesEvent', [], true);

            Me.Main = Me.Data.Posts.Main;
            Me.Actions = Me.Data.Posts.Actions;
            Me.Helpers = Me.Data.Posts.Helpers;
            //Me.Controls = Apps.Components.Common.Controls;
            //Me.Files = Me.Data.Posts.Files;

            callback();
        },
        GetToken: function (callback) {

            Apps.Components.Helpers.Debug.Trace(this);
            Apps.Components.Helpers.Auth.Passwordless.GetTokenUser(function (user) {

                if (user.IsSignedIn === true) {

                    //Me.ShowHome(result);
                    callback(true);
                }
                else {

                    //prompt for login
                    //result.AddSuccess('Not signed in.');

                    Apps.Notify('warning', 'Please sign in.');

                    Apps.Components.Home.ShowBackground();

                    Apps.Components.Helpers.Auth.Passwordless.Show(function (passcodeconfirmed) {

                        if (passcodeconfirmed) {
                            Apps.Components.Home.HideBackground();
                            Apps.Components.Helpers.Auth.Passwordless.Hide();

                            //Me.ShowHome(result);
                            callback(true);
                        }
                        else
                            callback(false);
                    });
                }

            });


        },
        Show: function () {

            Apps.Components.Helpers.Debug.Trace(this);

            let args = {
                "Params":
                    [
                        { "Name": "RequestCommand", "Value": "LogEntry" },
                        { "Name": "StepID", "Value": '0' },
                        { "Name": "AppID", "Value": 9 },
                        { "Name": "Severity", "Value": 1 },
                        { "Name": "Title", "Value": 'hiya' },
                        { "Name": "Description", "Value": 'there guys' },
                        { "Name": "UniqueID", "Value": 'HIYA_THERE_GUYS' }
                    ]
            };

            args.Params.push({ Name: 'Token',  Value: 'f64a7781-9c4e-4519-be7d-ef73c736c970' });
            args.Params.push({ Name: 'CustomerID', Value: '35' });

            Me.Data.Posts.Main.Refresh(args, [], function () {

            });

            Me.GetToken(function (signedin) {

                Me.UI.Show();
                Me.PutOnTop();
                Me.ShowApps();
                Me.Apps.GetData(); //Gets data and starts refresh interval
                Apps.Components.Helpers.UserSettings.RefreshUserSettings();

            });

        },
        PutOnTop: function () {

            Apps.Components.Helpers.Debug.Trace(this);

            $('.Stage_Container').css('z-index', '100');

            $('.HomeContent_Container').css('z-index', '200');
            $('.HeadsUp_StageButtons').children().removeClass('active');
            $('.StageButtons_Home').addClass('active');
        },
        ShowApps: function () {

            Apps.Components.Helpers.Debug.Trace(this);

            Me.Apps.GetAppsThumbnailsHTML(function (html) {
                $('#Home_AppThumbnails_Container').html(html);
            });
        },
        HandleError: function (result) {

            Apps.Components.Helpers.Debug.Trace(this);

            vNotify.error({ text: 'A problem ocurred on the server.', title: 'Server Error', sticky: false, showClose: true });
            let textDiv = $('body > div.vnotify-container.vn-top-right > div > div.vnotify-text');
            textDiv.append('<div class="btn btn-dark" style="margin-top:10px;" onclick="Apps.Components.Helpers.OpenResponse(\'' + escape(JSON.stringify(result)) + '\');">View Response</div>');

            Apps.Notify('danger', 'Problem getting report.');
            $('#Admin_Editor_EditSaveResult').text(JSON.stringify(result));

        },
        ShowBackground: function () {

            Apps.Components.Helpers.Debug.Trace(this);

            $('#Main_Modal_Background').show();
        },
        HideBackground: function () {

            Apps.Components.Helpers.Debug.Trace(this);

            $('#Main_Modal_Background').hide();
        }

    };
    return Me;
})