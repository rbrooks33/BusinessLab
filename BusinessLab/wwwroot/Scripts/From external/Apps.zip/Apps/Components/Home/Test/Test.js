﻿define([], function () {
    var Me = {
        Name: 'Home.Test',
        Color: '#1961AE',
        Initialize: function (callback) {

            callback();
        },
        Show: function () {

            Apps.Components.Helpers.Debug.Trace(this);

            Me.UI.Show();
            Me.PutOnTop();
        },
        PutOnTop: function () {

            Apps.Components.Helpers.Debug.Trace(this);

            $('.Stage_Container').css('z-index', '100');

            $('.Test_Container').css('z-index', '200');
            $('.HeadsUp_StageButtons').children().removeClass('active');
            $('.StageButtons_Test').addClass('active');
        }
    };
    return Me;
})