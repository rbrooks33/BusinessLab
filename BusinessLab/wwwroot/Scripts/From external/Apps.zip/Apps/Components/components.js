{
    "Components": [
        {
            "Name": "Home",
            "Load": true,
            "UI": true,
            "Initialize": true,
            "Components": [
               
                {
                    "Name": "Apps",
                    "Load": true,
                    "UI": true,
                    "Initialize": true
                },

                {
                    "Name": "Plan",
                    "Load": true,
                    "UI": true,
                    "Initialize": true,
                    "Components": [
                        {
                            "Name": "Areas",
                            "Load": true
                        },
                        {
                            "Name": "Workflows",
                            "Load": true
                        },
                        {
                            "Name": "Steps",
                            "Load": true,
                            "Initialize": true,
                            "UI": true
                        }

                    ]
                },
                {
                    "Name": "Create",
                    "Load": true,
                    "UI": true,
                    "Initialize": true
                },
                {
                    "Name": "Test",
                    "Load": true,
                    "UI": true,
                    "Initialize": true
                },
                {
                    "Name": "Publish",
                    "Load": true,
                    "UI": true,
                    "Initialize": true
                },
                {
                    "Name": "Track",
                    "Load": true,
                    "UI": true,
                    "Initialize": true
                }

            ]
        },
        {
            "Name": "ATEC",
            "Load": true,
            "Initialize": true,
            "UI": true,
            "Components": [
                {
                    "Name": "Admin",
                    "Load": true,
                    "Initialize": true,
                    "UI": true
                },
                {
                    "Name": "IT",
                    "Load": true,
                    "Initialize": true,
                    "UI": true,
                    "Components": [
                       {
                            "Name": "MySpecialty",
                            "Load": false,
                            "Initialize":true,
                            "UI": true,
                            "Components": [
                                {
                                    "Name": "LogApps",
                                    "Load": true,
                                    "Initialize": true,
                                    "UI": true,
                                    "Components": [
                                        {
                                            "Name": "Apps",
                                            "Load": true,
                                            "Initialize": true,
                                            "UI": false,
                                            "Components": [
                                                {
                                                    "Name": "TestTool",
                                                    "Load": true,
                                                    "Initialize": true,
                                                    "UI": true
                                                },
                                               {
                                                    "Name": "LogWhiteList",
                                                    "Load": true,
                                                    "Initialize": true,
                                                    "UI": true
                                                },
                                                {
                                                    "Name": "CRMTools",
                                                    "Load": true,
                                                    "Initialize": true,
                                                    "UI": true
                                                },
                                               {
                                                    "Name": "LiveSitePinger",
                                                    "Load": true,
                                                    "Initialize": true,
                                                    "UI": true

                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "Name": "Workflows",
                                    "Load": true,
                                    "Initialize": true,
                                    "UI": true
                                },
                                {
                                    "Name": "Areas",
                                    "Load": true,
                                    "Initialize": true,
                                    "UI": true
                                },
                                {
                                    "Name": "UserSettings",
                                    "Load": true,
                                    "Initialize": true,
                                    "UI": true
                                }

                            ]
                        },
                        {
                            "Name": "PageCacher",
                            "Load": true,
                            "UI": true,
                            "Initialize":true
                        }
                    ]
                },
                {
                    "Name": "Sales",
                    "Load": true,
                    "Initialize": true,
                    "UI": false,
                    "Components": [
                        {
                            "Name": "AbandonedCartLeads",
                            "Load": true,
                            "Initialize": true,
                            "UI": true
                        },
                        {
                            "Name": "SalesWizard",
                            "Load": true,
                            "Initialize": true,
                            "UI": true
                        }

                    ]
                },
                {
                    "Name": "Services",
                    "Load": true,
                    "Initialize": true,
                    "UI": false
                }
            ]
        },

        {
            "Name": "Helpers",
            "Load": true,
            "Initialize": true,
            "UI": false,
            "Components": [
                {
                    "Name": "Actions",
                    "Load": true,
                    "UI": true,
                    "Initialize": true

                },
                {
                    "Name": "Auth",
                    "Load": true,
                    "Initialize": true,
                    "UI": true,
                    "Components": [
                        {
                            "Name": "Google",
                            "Load": true,
                            "Initialize": true,
                            "UI": true
                        },
                        {
                            "Name": "Microsoft",
                            "Load": false,
                            "Initialize": true,
                            "UI": true
                        },
                        {
                            "Name": "Passwordless",
                            "Load": true,
                            "Initialize": true,
                            "UI": true
                        }

                    ]
                },
                {
                    "Name": "PushHub",
                    "Load": true,
                    "Initialize": true,
                    "UI": false
                },
                {
                    "Name": "Controls",
                    "Load": true,
                    "Initialize": true,
                    "UI": false,
                    "Components": [
                        {
                            "Name": "QuickGrid",
                            "Load": true,
                            "Initialize": true,
                            "UI": false
                        },
                        {
                            "Name": "QuickTable",
                            "Load": true,
                            "Initialize": true,
                            "UI": false
                        }

                    ]
                },
                {
                    "Name": "Debug",
                    "Load": true,
                    "Initialize": true,
                    "UI": true
                },
                {
                    "Name": "Dialogs",
                    "Load": true,
                    "Initialize": true,
                    "UI": true
                },
                {
                    "Name": "UserSettings",
                    "Load": true,
                    "UI": true,
                    "Initialize": true
                }

            ]
        }
    ]
}