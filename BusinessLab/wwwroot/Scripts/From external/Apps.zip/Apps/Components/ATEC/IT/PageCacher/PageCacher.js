﻿define([], function () {
    var Me = {
        CycleList: [],
        Initialize: function (callback) {
            Me.HelpersPost = Apps.Components.Helpers.Data.Posts.HelpersPost;
            callback();
        },
        Show: function (app) {

            Apps.Components.Home.Apps.GetAppLogs(app.AppID, function (logs) {

                Me.Logs = logs;

                //let cycleHistory = Enumerable.From(logs).Where(l => l.StepID == 9 || l.StepID == 10).OrderByDescending(l => l.Created).ToArray();


                Me.GetCycleHistoryHTML(function (cycleHtml) {

                    let html = Me.UI.Templates.IT_PageCacher_Main.HTML(['', cycleHtml]);

                    Apps.Components.Home.Apps.DropApp(app, html);
                });

            });
            //Me.GetHTML();
        },
        ShowInPage: function () {
        //    Apps.Components.Home.Apps.GetAppLogs(8, function (logs) {

        //        Me.Logs = logs;

        //    });
            Me.GetHTML();
        },
        GetHTML: function (filterType, filterId) {

            var result = new Apps.Result();

            Me.GetFailPingsHTML(function (failPingHTML, totalFail){
                Me.GetLongPingsHTML(function (longPingHTML, totalLong) {
                    Me.GetCycleHistoryHTML(function (cycleHtml) {

                        let html = Me.UI.Templates.IT_PageCacher_Main.HTML([longPingHTML, cycleHtml, failPingHTML, totalLong, totalFail]);
                        let titleHtml = '    <h1>Page Cacher Stats</h1> <p>Toward Live Site Performance Improvements</p>';

                        $('#PageCacher_IndexPageContent').html(titleHtml + html);
                    });

                });
            });

        },
        GetCycleHistoryHTML: function (callback) {

            let args = {
                Params: [
                    { Name: "RequestName", Value: "RunAction" },
                    { Name: "ActionID", Value: "1" },
                    { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                    { Name: "CustomerID", Value: "0" }
                ]
            }

            Me.HelpersPost.Refresh(args, [], function () {
                if (Me.HelpersPost.Success) {

                    Me.CycleList = Me.HelpersPost.Data;

                    callback(Apps.Components.Helpers.Controls.QuickTable.GetTable(Me.HelpersPost.Data, function () {
                        return `<tr><th></th><th>Cycle ID</th><th>Start</th><th>Finish</th><th>Elapsed</th></tr>`; 
                    }, function (row) {

                        let start = row.CycleStart ? Apps.Util.FormatDateTime2(new Date(row.CycleStart)) : '';
                        let end = row.CycleEnd ? Apps.Util.FormatDateTime2(new Date(row.CycleEnd)) : '';
                        let elapsed = '';

                        if(row.CycleStart && row.CycleEnd)
                            elapsed = Apps.Util.TimeElapsedBetween(new Date(row.CycleStart), new Date(row.CycleEnd));

                        return `<tr><td><div class="btn btn-primary" onclick="Apps.Components.ATEC.IT.PageCacher.FilterByCycle(${row.CycleID});">Filter</div></td><td>${row.CycleID}</td><td>${start}</td><td>${end}</td><td>${elapsed}</td></tr>`; 
                    }));

                }
                else
                    Apps.Components.Home.HandleError(Me.HelpersPost.Result);
            });

            //return ''; // html;
        },
        GetLongPingsHTML: function (result, callback) {

                //let longPings = Enumerable.From(Me.Logs).Where(l => l.StepID == 12 && new Date(l.LastPing) < new Date()).ToArray();
            let args = {
                Params: [
                    { Name: "RequestName", Value: "RunAction" },
                    { Name: "ActionID", Value: "2" },
                    { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                    { Name: "CustomerID", Value: "0" }
                ]
            }

            Me.HelpersPost.Refresh(args, [], function () {

                if (Me.HelpersPost.Success) {

                    let percentSorted = Enumerable.From(Me.HelpersPost.Data)
                        .OrderByDescending(d => d.MaxPingSeconds)
                        .ThenBy(d => d.PercentOfTotalCycles)
                        .ToArray();

                    let html = Apps.Components.Helpers.Controls.QuickTable.GetTable(percentSorted);

                   // $('#IT_PageCacher_TotalLongPings').text(percentSorted.length);

                    callback(html, percentSorted.length);
                }
                else
                    Apps.Components.Home.HandleError(Me.HelpersPost.Result);
            });
        },
        GetFailPingsHTML: function (callback) {

            let args = {
                Params: [
                    { Name: "RequestName", Value: "RunAction" },
                    { Name: "ActionID", Value: "3" },
                    { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                    { Name: "CustomerID", Value: "0" }
                ]
            }

            Me.HelpersPost.Refresh(args, [], function () {

                if (Me.HelpersPost.Success) {

                    let percentSorted = Enumerable.From(Me.HelpersPost.Data)
                        .OrderBy(d => d.UniqueID)
                        .ToArray();

                    let html = Apps.Components.Helpers.Controls.QuickTable.GetTable(percentSorted,
                        function () {
                            return `<tr><th>Node ID</th><th>Page</th><th>Ping Date</th>></tr>`;
                        },
                        function (row) {
                            return `<tr><td>${row.UniqueID}</td><td>${row.Title}</td><td>${Apps.Util.FormatDateTime2(new Date(row.Created))}</td></tr>`;
                        });

                   // $('#IT_PageCacher_TotalFailPings').text(percentSorted.length);

                    callback(html, percentSorted.length);
                }
                else
                    Apps.Components.Home.HandleError(Me.HelpersPost.Result);
            });

        },
        FilterByCycle: function (cycleId) {

        }
    };
    return Me;
})