﻿define([], function () {
    var Me = {
        Initialize: function (callback) {

            Apps.Data.RegisterMyPOST(Me, 'API', Apps.ActiveDeployment.WebRoot + '/api/main', [], true);
            callback();
        },
        Post: function (args, callback) {

            let api = Me.Data.Posts.API;

            Apps.Components.Helpers.Debug.Trace(this, JSON.stringify(args));

            args.Params.push({ Name: 'Token', Value: Apps.Components.Helpers.Auth.User.Token });
            args.Params.push({ Name: 'CustomerID', Value: "0" });

            api.Refresh(args, [], function () {

                if (api.Success) {
                    callback(api);
                }
                else {
                    Me.LogEntry(4, 'Error Executing Post', JSON.stringify(api.Result), 'ATEC_API_POST_EXCEPTION');
                    Apps.Components.Helpers.HandleError(api.Result); //TODO: Use a more appropriate overall server error handler
                }
            });
        },
        LogEntry: function (severity, title, description, uniqueid, stepid) {

            Apps.Components.Helpers.Debug.Trace(this);

            let post = Me.Data.Posts.API;

            let args = {
                "Params":
                    [
                        { "Name": "RequestCommand", "Value": "LogEntry" },
                        { "Name": "StepID", "Value": (stepid ? stepid.toString() : '0') },
                        { "Name": "AppID", "Value": 9 },
                        { "Name": "Severity", "Value": severity.toString() },
                        { "Name": "Title", "Value": title },
                        { "Name": "Description", "Value": description },
                        { "Name": "UniqueID", "Value": (uniqueid ? uniqueid.toString() : '') }
                    ]
            };

            args.Params.push({ Name: 'Token', Value: Apps.Components.Helpers.Auth.User.Token });
            args.Params.push({ Name: 'CustomerID', Value: "0" });

            post.Refresh(args, [], function () {

                if (post.Success) {
                    //callback(post);
                }
                else {
                    Apps.Components.Helpers.HandleError(post.Result); //TODO: Use a more appropriate overall server error handler
                }
            });
        },

    };
    return Me;
});