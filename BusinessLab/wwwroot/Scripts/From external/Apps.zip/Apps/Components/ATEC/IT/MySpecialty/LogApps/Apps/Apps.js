﻿define([], function () {
    var Me = {
        Initialize: function (callback) {

            if (callback)
                callback();
        }
    };
    return Me;
});