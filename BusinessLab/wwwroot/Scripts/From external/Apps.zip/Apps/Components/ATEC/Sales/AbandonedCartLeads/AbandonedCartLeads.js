﻿define([], function () {
    var Me = {
        AppsLogs: [],
        Initialize: function (callback) {
            callback();
            Apps.Data.RegisterMyPOST(Me, 'AbandonedCartLeads', Apps.ActiveDeployment.WebRoot + '/api/main', [], true);
        },
        Show: function () {

            Apps.Components.Home.Apps.GetAppLogs(Apps.Components.Home.Apps.SelectedApp.AppID, function (appLogs) {

                Me.AppsLogs = appLogs;

                Me.GetHTML(function (html) {

                    $('#MySpecialty_ShowApp_Container_7').detach();

                    Apps.Components.Home.Apps.DropApp(Apps.Components.Home.Apps.SelectedApp, html);
                    Me.GetEnabled();

                    $('#AbandonedCartLeads_Criteria1_Input').val(Me.GetParam('Criteria1').Value);
                    $('#AbandonedCartLeads_Criteria2_Input').val(Me.GetParam('Criteria2').Value);
                });

            });

        },
        GetHTML: function (htmlCallback) {

            let post = Me.Data.Posts.AbandonedCartLeads;


            Apps.Components.Home.Apps.GetAppLogs(Apps.Components.Home.Apps.SelectedApp.AppID, function (appLogs) {

                Me.AppsLogs = appLogs;

                let args = {
                    "Params": [
                        { "Name": "RequestCommand", "Value": "AbandonedCartLeads.GetAbandonedCartLeads" },
                        { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                        { Name: "CustomerID", Value: "0" }
                    ]
                };

                post.Refresh(args, [], function () {

                    if (post.Success) {
                        

                        //Cart views
                        let viewData = Enumerable.From(Me.AppsLogs).OrderByDescending(l => l.Created).ToArray();
                        let views = '';
                        $.each(viewData, function (index, v) {

                            views += '<tr>';
                            views += '<td>' + Apps.Util.TimeElapsed(new Date(v.Created)) + '</td>';
                            views += '<td>' + v.UniqueID + '</td>';
                            //views += '<td>' + v.Description + '</td>';
                            views += '</tr>';
                        });
                        views = Me.UI.Templates.ACL_LogViews_Table.HTML([views]);

                        //potential leads html (AbandonedCartLead table)
                        let potentialLeads = Enumerable.From(post.Data).OrderByDescending(l => l.Updated).ToArray();
                        let html = '';
                        html += '<table class="table">';
                        html += '<tr>';
                        html += '<th>Created</th>';
                        html += '<th>Updated</th>';
                        html += '<th>UserID</th>';
                        html += '<th>Name</th>';
                        html += '<th>Last Checked</th>';
                        html += '<th>Last Order Date</th>';
                        html += '<th>Last Lead Created</th>';
                        html += '<th>Create Lead?</th>';
                        html += '</tr>';

                        $.each(potentialLeads, function (index, lc) {

                            let updated = lc.Updated ? Apps.Util.TimeElapsed(new Date(lc.Updated)) : '';
                            let qualified = lc.Qualified ? '<i class="fa-solid fa-check" style="color: #389469;"></i>' : '<i class="fa-solid fa-x" style="color: #d31717;"></i>';
                            let lastOrdered = lc.LastOrderDate && new Date(lc.LastOrderDate).getYear() >= new Date().getYear() ? Apps.Util.TimeElapsed(new Date(lc.LastOrderDate)) : '';
                            let lastLead = lc.LastLeadCreated ? Apps.Util.TimeElapsed(new Date(lc.LastLeadCreated)) : '';

                            html += '<tr>';
                            html += '<td>' + Apps.Util.TimeElapsed(new Date(lc.Created)) + ' </br>(' + Apps.Util.FormatDateTime2(new Date(lc.Created)) + ')</td>';
                            html += '<td>' + updated + '</td>';
                            html += '<td>' + lc.CustomerUserID + '</td>';
                            html += '<td>' + lc.FirstName + ' ' + lc.LastName + '</td>';
                            html += '<td>' + Apps.Util.TimeElapsed(new Date(lc.LastCartCheck)) + '</td>';
                            html += '<td>' + lastOrdered + '</td>';
                            html += '<td>' + lastLead + '</td>';
                            html += '<td>' + qualified + '</td>';
                            html += '</tr>';
                        });

                        html += '</table>';

                        html = Me.UI.Templates.ACL_Main.HTML([html, views]);



                        htmlCallback(html);

                    }
                    else
                        Apps.Components.Home.HandleError(post.Result);

                });
            });
        },
        SetEnabled: function () {

            let post = Me.Data.Posts.AbandonedCartLeads;
            let enabled = $('#AbandonedCartLeads_Enabled_Checkbox').prop('checked');
            let args = {
                "Params": [
                    { "Name": "RequestCommand", "Value": "AbandonedCartLeads.SetEnabled" },
                    { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                    { Name: "CustomerID", Value: "0" }
                ]
            };

            args.Params.push({ "Name": "Enabled", "Value": (enabled ? "true" : "false") });

            post.Refresh(args, [], function () {



                if (post.Success) {
                    //Apps.Notify('success', 'Abandoned Cart Leads Feature has been ' + (enabled ? "enabled" : "disabled"));

                    if (enabled)
                        Apps.Notify('success', 'Note: Abandoned Cart Leads Feature has been ENABLED');
                    else
                        Apps.Notify('warning', 'Note: Abandoned Cart Leads Feature has been DISABLED');

                    $('#SelectedApp_EnabledText_Span').text(enabled ? 'Active' : 'Inactive').css('color', enabled ? 'green': 'red');

                }
                else
                    Apps.Components.Home.HandleError(post.Result);
            });

        },
        GetEnabled: function () {

            let post = Me.Data.Posts.AbandonedCartLeads;
            let args = {
                "Params": [
                    { "Name": "RequestCommand", "Value": "AbandonedCartLeads.GetEnabled" },
                    { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                    { Name: "CustomerID", Value: "0" }
                ]
            };
            post.Refresh(args, [], function () {

                if (post.Success) {

                    if (post.Data)
                        Apps.Notify('success', 'Note: Abandoned Cart Leads Feature is ENABLED');
                    else
                        Apps.Notify('warning', 'Note: Abandoned Cart Leads Feature is DISABLED');

                    $('#SelectedApp_EnabledText_Span').text(post.Data ? 'Active' : 'Inactive').css('color', post.Data ? 'green' : 'red');

                    $('#AbandonedCartLeads_Enabled_Checkbox').prop('checked', post.Data);
                }
                else
                    Apps.Components.Home.HandleError(post.Result);
            });


        },
        TestCartView: function () {
            let post = Me.Data.Posts.AbandonedCartLeads;
            let userid = $('#ACLUsersDropdown').val();
            let args = {
                "Params":
                    [
                        { "Name": "RequestCommand", "Value": "LogEntry" },
                        { "Name": "StepID", "Value": "8" },
                        { "Name": "Severity", "Value": "2" },
                        { "Name": "Title", "Value": "Abandoned Cart Check" },
                        { "Name": "Description", "Value": "6dc13af4-0ba8-4e5d-b73c-80b9d71d9073|6dc13af4-0ba8-4e5d-b73c-80b9d71d9073" },
                        { "Name": "UniqueID", "Value": userid.toString() },
                        { Name: "AppID", Value: 7},
                        { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                        { Name: "CustomerID", Value: "0" }
                    ]
            };
            post.Refresh(args, [], function () {
                if (!post.Success) {
                    Apps.Notify('warning', 'Problem submitting a test cart view.');
                }
                else {
                    Me.Show();
                }
            });
        },
        ClearCartViews: function () {

            let post = Me.Data.Posts.AbandonedCartLeads;
            if (confirm('Are you sure?')) {
                //Apps.Notify('success', 'yes');

                let args = {
                    "Params":
                        [{
                            "Name": "RequestCommand", "Value": "AbandonedCartLeads.ClearCartViews"
                        },
                            { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                            { Name: "CustomerID", Value: "0" }
                        ]
                };
                post.Refresh(args, [], function () {

                    if (post.Success) {
                        Apps.Notify('success', 'Cart views cleared.');
                        Me.Show();
                    }
                    else
                        Apps.Components.Home.HandleError(post.Result);

                })

            }
        //    else
        //        Apps.Notify('success', 'no');
        },
        UpdatePotentialLeads: function () {
            let post = Me.Data.Posts.AbandonedCartLeads;
            let args = {
                "Params":
                    [
                        { "Name": "RequestCommand", "Value": "AbandonedCartLeads.Upsert" },
                        { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                        { Name: "CustomerID", Value: "0" }
                    ]
            };
            post.Refresh(args, [], function () {
                if (post.Success) {
                    Me.Show();
                }
                else
                    Apps.Notify('warning', 'Problem upserting potential leads table.');
            });
        },
        ClearPotentialLeads: function () {

            let post = Me.Data.Posts.AbandonedCartLeads;

            if (confirm('Are you sure?')) {

                //Apps.Notify('success', 'yes');

                let args = {
                    "Params":
                        [
                            { "Name": "RequestCommand", "Value": "AbandonedCartLeads.ClearPotentialLeads" },
                            { Name: "Token", Value: Apps.Components.Helpers.Auth.User.Token },
                            { Name: "CustomerID", Value: "0" }
                        ]
                };


                post.Refresh(args, [], function () {
                    if (post.Success) {

                        Apps.Notify('success', 'Potential lead table cleared.');
                        Me.Show();
                    }
                    else
                        Apps.Components.Home.HandleError(post.Result);

                })
            }
        //    else
        //        Apps.Notify('success', 'no');
        },
        GetAppResult: function () {
            let app = Apps.Components.Home.Apps.SelectedApp;

            if (app.Result == null) {

                app.Result = new Apps.Result();
                app.Result.Params = [];
            }
            else {
                if (app.Result.Params == null) {
                    app.Result.Params = [];
                }
            }
            Apps.Components.Home.Apps.SelectedApp.Result = app.Result; //??

            return app.Result;
        },
        UpdateParam: function (paramName, paramValue) {

            var result = Me.GetAppResult();

            for (var p in result.Params) {
                if(result.Params[p])
                    if (result.Params[p].Name == paramName)
                        delete result.Params[p];
            }

            result.Params.push({ Name: paramName, Value: paramValue });

            Apps.Notify('info', 'Criteria value has been updated to ' + paramValue);
        },
        GetParam: function (paramName) {
            var result = Me.GetAppResult();
            var param = null;

            for (var p in result.Params) {
                if (result.Params[p])
                    if (result.Params[p].Name == paramName)
                        param = result.Params[p];
            }

            if (param == null)
                param = { Name: '', Value: '' };

            return param
        },
        UpdateCriteria1: function () {
            //must be after so many days lead created
            Me.UpdateParam('Criteria1', $('#AbandonedCartLeads_Criteria1_Input').val());
            Apps.Components.Home.Apps.SaveApp();
        },
        UpdateCriteria2: function () {
            //no more than past last activity
            Me.UpdateParam('Criteria2', $('#AbandonedCartLeads_Criteria2_Input').val());
            Apps.Components.Home.Apps.SaveApp();
        },
        CreateLeads: function () {
            let post = Apps.Components.Helpers.Data.Posts.Main; //goes to helpers api
            let args = {
                Params: [
                    { Name: 'RequestName', Value: 'RunAction' },
                    { Name: 'ActionID', Value: '5' }
                ]
            };
            post.Refresh(args, [], function () {
                if (post.Success) {
                    Apps.Notify('success', 'Action 5 was run successfully.');

                    let text = 'Success Messages:\n\n';
                    $.each(post.Result.SuccessMessages, function (i, m) {
                        text += m + '\n';
                    });

                    text += '\n\nFail Messages:\n\n';
                    $.each(post.Result.FailMessages, function (i, m) {
                        text += m + '\n';
                    });

                    $('#ACL_LeadCreationResult_Text').text(text);
                }
                else
                    Apps.Components.Home.HandleError(post.Result);
            });
        }
    };
    return Me;
});