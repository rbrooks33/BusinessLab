﻿define([], function () {
    var Me = {
        Initialize: function (callback) {

            Apps.Data.RegisterMyGET(Me, 'Jira', 'https://atecorp.atlassian.net/rest/api/latest/search', [], false);

            callback();
        },
        Show: function (app) {

            var me = Apps.Components.Home.Apps.SelectedApp;
            Apps.Components.Home.Apps.GetAppLogs(me.AppID, function (appLogs) {

                Me.AppsLogs = appLogs;

                let myHtml = 'hiya';

                let html = Apps.Components.Home.Apps.UI.Templates.Apps_ShowApp.HTML([me.AppID, me.AppName, '', myHtml]);

                $(document.body).append(html); //put on body

                $('#MySpecialty_ShowApp_Container_9').show(); //show it


                let tasksHtml = '';


                let homeHtml = Me.UI.Templates.SalesWizard_Home.HTML([]);

                Me.GetTasks();
            });

        },
        GetTasks: function () {

            let jira = Me.Data.Gets.Jira;

            Apps.SaveAuthenticationData('cmJyb29rc0BhdGVjb3JwLmNvbTpBVEFUVDN4RmZHRjA1aUFhalBURXZhS0tFVXVmdDRVbU1sWFR0RUp1eWpiTzY5VmlfelJWM05vSkNsOF9kUUpGMkxMNUJ3cGJFU1pRTnF3TGludE56TXlpOHVIY25zUGtrUFhtcUxSMDlZcDRMaVhuNloxVy11NFhEcnNYZElYSnYwR2plNVR4WUpxbkZMaEhvUXhrUWZza2JiRU9TaXNRZ01DRWlvVWNlU1hFQlhSWkhyek00b1k9QUNENkM5REQ=');

            jira.Refresh(null, function () {


            });
        }
    };
    return Me;
});