﻿define([], function () {
    var Me = {
        Initialize: function (callback) {
            callback();
        }
    };
    return Me;
});